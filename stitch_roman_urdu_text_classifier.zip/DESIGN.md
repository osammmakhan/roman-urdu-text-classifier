---
name: Syntactic Slate
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353942'
  surface-container-lowest: '#0a0e16'
  surface-container-low: '#181c24'
  surface-container: '#1c2028'
  surface-container-high: '#262a33'
  surface-container-highest: '#31353e'
  on-surface: '#dfe2ee'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dfe2ee'
  inverse-on-surface: '#2c3039'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#c0c1ff'
  on-secondary: '#1000a9'
  secondary-container: '#3131c0'
  on-secondary-container: '#b0b2ff'
  tertiary: '#4cd7f6'
  on-tertiary: '#003640'
  tertiary-container: '#00b2d0'
  on-tertiary-container: '#003f4b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#0f131c'
  on-background: '#dfe2ee'
  surface-variant: '#31353e'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: '0'
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: '0'
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: '0'
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
  code-token:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-base: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  sidebar-width: 16rem
  inspector-width: 24rem
---

## Brand & Style

This design system embodies a high-precision, computational deep-tech aesthetic tailored for cross-lingual NLP engineering and Latin-scripted Urdu analysis. The interface conveys cognitive authority, forensic precision, and technological elegance. It evokes the sensation of working within an advanced telemetry laboratory or neural computation matrix: calm, dark, mathematically ordered, yet punctuated by high-signal luminescent telemetry.

The visual direction merges **Technical Minimalism** with **Refined Glassmorphism**. Structural foundations leverage deep carbon, obsidian, and slate tones to reduce cognitive fatigue during dense data inspection. Translucent glass substrates, microscopic hair-line borders, and calibrated spectral emissions (vibrant emerald for high-confidence predictions/clean status, electric indigo for latent vector spaces and active inference) elevate the product above conventional developer consoles into a specialized, state-of-the-art NLP workbench.

## Colors

The system uses a calibrated dark-mode chromatic hierarchy optimized for parsing mixed Latin script, confidence scores, and categorical matrices.

- **Primary (`#10B981` Emerald)**: Represents positive classifications, verified corpus extractions, high-accuracy inference confidence (e.g., >0.90), and real-time API uptime.
- **Secondary (`#6366F1` Electric Indigo)**: Marks latent token transformations, computational models, active selection rings, and neural layer operations.
- **Tertiary (`#06B6D4` Cyan)**: Denotes lexical tokens, n-gram markers, and Roman Urdu dialect variant flags.
- **Neutral Surface Hierarchy**:
  - `Base Canvas`: `#070A0F` (abyssal black-slate)
  - `Surface Tier 1`: `#0B0F17` (slate foundation)
  - `Surface Tier 2 (Cards & Panels)`: `#111827` with 70–85% alpha blending
  - `Border / Hairlines`: `rgba(255, 255, 255, 0.08)` to `rgba(99, 102, 241, 0.2)` for focused boundaries
- **Semantic Feedback**:
  - `Toxic / Hate / Hazard`: `#F43F5E` (rose-red)
  - `Spam / Ambiguity`: `#F59E0B` (amber-gold)
  - `Neutral / Informational`: `#64748B` (cool slate)

## Typography

The typographic hierarchy addresses the specialized challenge of rendering informal, phonetically varied Roman Urdu (e.g., "aap kaisa hain", "ye setting theek nahi chal rahi") alongside complex classification matrices.

- **Headlines (Space Grotesk)**: Imparts structural authority, geometric tension, and modern technological poise for dashboard metrics, page titles, and view headers.
- **Body Text (Geist)**: Delivers exceptional legibility for user-submitted text feeds, dataset rows, multi-line Roman Urdu syntax, and explanatory copy.
- **Data & Telemetry (JetBrains Mono)**: Reserved for model loss rates, tokenized substrings, F1/Precision scores, probability distributions, and raw payload bodies. Tabular figures are enforced for numerical column stability.

## Layout & Spacing

The layout philosophy follows a **Dense Data Fluid Grid** with structured viewport anchors. It maximizes vertical and horizontal scanning efficiency for data analysts and ML engineers.

- **Grid Framework**: 12-column adaptive system with variable-width sub-grids for analysis panes.
  - **Desktop (>=1280px)**: Persistent collapsible 16rem navigation spine, dynamic workspace area, and a 24rem context-sensitive model inspection side-drawer. Gutters locked to `1.5rem` (`space-lg`).
  - **Tablet (768px - 1279px)**: Inspector collapses into a bottom modal sheet; primary dashboard switches to an 8-column layout with `1rem` (`space-base`) gutters.
  - **Mobile (<768px)**: Unified single-column stack with persistent bottom command bar, sticky prediction summaries, and safe margins of `1rem`.
- **Rhythm**: Spacing follows a 4px mathematical grid (`space-xs` = 4px, `space-sm` = 8px, `space-base` = 16px). Information density is preserved through tight component-internal padding (`space-xs` to `space-sm`) paired with generous macro-structural breathing room (`space-xl` to `space-2xl`).

## Elevation & Depth

Visual hierarchy is constructed through **Multi-Layered Glassmorphism** coupled with **Luminescent Backdrops** rather than muddy dropshadows.

- **Background Zero**: Deep abyssal canvas (`#070A0F`) with subtle radial gradients of indigo (`rgba(99, 102, 241, 0.05)`) positioned under active analytical clusters.
- **Glass Tier 1 (Panels & Shells)**: `rgba(17, 24, 39, 0.65)` with `backdrop-filter: blur(16px)` and a uniform top hairline `border: 1px solid rgba(255, 255, 255, 0.06)`.
- **Glass Tier 2 (Interactive Cards & Popovers)**: `rgba(22, 30, 46, 0.85)` with `backdrop-filter: blur(24px)`, paired with an ambient diffuse shadow: `0 8px 32px -4px rgba(0, 0, 0, 0.5)`.
- **Glow & Signal Fields**: Elements bearing high confidence or critical classification trigger soft perimeter luminescence (`box-shadow: 0 0 20px -3px rgba(16, 185, 129, 0.25)` for verified emerald signals; `rgba(244, 63, 94, 0.3)` for toxic alerts).

## Shapes

The design system adopts a **Soft Precision (`roundedness: 1`)** geometry. Crisp lines and restrained radii reflect mathematical exactness, preventing the interface from feeling toy-like.

- **Micro elements (Badges, Pills, Buttons)**: `0.25rem` (4px) to `0.375rem` (6px).
- **Cards & Data Tables**: `0.5rem` (8px).
- **Floating Modals & Inspection Panes**: `0.75rem` (12px).
- **Token Tags**: Minimalist boundary boxes with `0.25rem` radius, preserving character density when rendering continuous Roman Urdu token sequences.

## Components

### Buttons
- **Primary (Inference / Run Pipeline)**: Gradient fill transitioning from `#10B981` to `#059669` with black text (`#02120B`), font weight 500 (`Geist`), and subtle inner top highlight. Hover triggers a radiant emerald shadow (`0 0 16px rgba(16, 185, 129, 0.4)`).
- **Secondary (Model Switcher / Export)**: Translucent glass button (`rgba(255, 255, 255, 0.04)`), crisp 1px border (`rgba(255, 255, 255, 0.1)`), glowing hover state transitioning to `rgba(99, 102, 241, 0.15)` with electric indigo text.
- **Ghost / Icon**: Zero background, neutral slate hover, active state shrinks by 2% scale (`scale(0.98)`).

### Input Fields & Tokenizers
- **Roman Urdu Text Area**: Expansive text container with dark glass fill (`rgba(11, 15, 23, 0.7)`), 1px slate-800 border. Focus mode illuminates the border in electric indigo (`#6366F1`) with zero offset ring.
- **Live Token Highlighting**: When parsed, detected slang, abusive terms, and positive markers are rendered inline with translucent colored bounding boxes (e.g., toxic words highlighted in `rgba(244, 63, 94, 0.15)` with a 1px dotted rose underline).

### Chips & Classification Badges
- **Format**: Pill-like structure using `label-sm` in `JetBrains Mono`.
- **Confidence Badge**: Displays categorical verdict (e.g., `SENTIMENT: POSITIVE`, `TOXIC: 0.94`, `SPAM: FALSE`).
- **Telemetry Indicators**: Micro circle status dot (4px) embedded on the left, pulsing softly for ongoing background classification jobs.

### Cards & Analytical Containers
- Built on Glass Tier 1. Top border features a delicate directional gradient (`from-white/10 to-transparent`).
- Headers feature title in `headline-sm` with active batch count or latency indicators aligned to the right in `label-sm`.

### Checkboxes, Toggles & Radios
- **Checkboxes**: 14px squared boxes with rounded-xs edges. Unchecked is a dark slate void with faint outline; checked displays an emerald fill with sharp white check vector.
- **Model Comparison Toggles**: Recessed switch track (`rgba(0,0,0,0.5)`) with an electric indigo slider thumb that glows softly when engaged.

### Lists & Matrix Tables
- Alternating row zebra effect suppressed in favor of hairline separators (`rgba(255, 255, 255, 0.04)`).
- Hovering over a dataset item renders an indigo edge bar on the left (2px width) and lifts background opacity to `rgba(255, 255, 255, 0.02)`.

### Specialized NLP Components
- **Per-Token Probability Inspector**: A horizontal multi-segment bar breaking down word-level attention weights.
- **Confusion Matrix Tile**: Heatmap grid cells utilizing opacity gradients of electric indigo to reveal classification accuracy across Roman Urdu dialectical variations.